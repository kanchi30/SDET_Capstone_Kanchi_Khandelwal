package basepages;

public class RegisterPage extends Pages {

	public void clickRegister()
	{
		click("Register");
	}

	public void enterName(String Fname , String Lname)
	{
		type("FirstName", Fname);
		type("LastName", Lname);
	}
	
	public void EmailPassword(String email , String pass1 , String pass2) throws Exception
	{
		type("Email" , email);
		if(pass1.equals(pass2))
		{
		type("Password1", pass1);
		type("Password2",pass2);
		}
		else
		{
			throw new Exception("Password & confirm Password not same");
		}
	}
	
	public void BirthDate(String date)
	{
		int index = date.indexOf("/");
		String month = date.substring(0, index); 
		String year  = date.substring(index+1, date.length());
		System.out.println("Year ::"+year);
		selectText("BirthMonth" , month);
		selectText("BirthYear" , year);
	}

	public void zipcode(String zipcode)
	{
		type("Zipcode",zipcode);
	}
	
	public void clickTerms()
	{
		click("T&C");
	}
	
	public void submit()
	{
		click("Submit");
	}
	
	public boolean titleCheck(String text)
	{
		System.out.println(driver.getTitle());
		return(driver.getTitle().equalsIgnoreCase(text));
	}
	
	}
