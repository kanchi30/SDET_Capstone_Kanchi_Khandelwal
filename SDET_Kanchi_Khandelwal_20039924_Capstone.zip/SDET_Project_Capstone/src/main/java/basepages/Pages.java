package basepages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Pages {
	public static WebDriver driver;
	 
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static WebDriverWait wait;
	
	public Pages()
	{
		if (driver == null) {

			try {
				fis = new FileInputStream(System.getProperty("user.dir")
						+ "/src/test/resources/properties/config.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				config.load(fis);
				log.debug("Config file loaded !!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				fis = new FileInputStream(
						System.getProperty("user.dir") + "/src/test/resources/properties/OR.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				OR.load(fis);
				log.debug("OR file loaded !!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			}
	}
	
	public static void start() {
		if (config.getProperty("browser").equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
				log.info("Firefox loaded !!!");

		} 
		else if (config.getProperty("browser").equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			log.info("Chrome loaded !!!");
		}
				
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, Integer.parseInt(config.getProperty("explicit.wait")));
		driver.manage().timeouts().pageLoadTimeout(200, TimeUnit.SECONDS);		
	}
	
	public static void close()
	{
		driver.quit();
	}
	
	public static void navigatetoURL(String URL)
	{
		driver.get(URL);
		log.debug("navigated to URL :" + URL );
	}
	
	public static void click(String locator) {

		driver.findElement(By.xpath(OR.getProperty(locator))).click();
		log.debug("Clicking on an Element : "+locator);
		
	}
	
	public static void type(String locator,String value) {

		driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);
		log.debug("Typing on an Element : "+locator + "with value as" + value);
		
	}
	
	public static String gettext(String locator)
	{
		return (driver.findElement(By.xpath(OR.getProperty(locator)))).getText();
	}
	
	public static void clickDate(String locator1, String locator2, String date)
	{
		driver.findElement(By.xpath(OR.getProperty(locator1)+date+OR.getProperty(locator2))).click();
	}
	
	public void movetoElement(String locator)
	{
		new Actions(driver).moveToElement(driver.findElement(By.xpath(OR.getProperty(locator)))).perform();
	}
	
	
	public void selectText(String locator , String value)
	{
		new Select(driver.findElement(By.xpath(OR.getProperty(locator)))).selectByValue(value);
		log.debug("Selected value :" + value);
	}
	
	

}
	
	
	
