package basepages;

import org.testng.Assert;

import Utility.EmailUtils;

public class ResetPage extends Pages {
		
	static EmailUtils emailUtils;
	
	 public static void connectToEmail() {
		    try {
		      emailUtils = new EmailUtils("shrutiss095", "kanchi@95", "smtp.gmail.com", EmailUtils.EmailFolder.INBOX);
		    } catch (Exception e) {
		      e.printStackTrace();
		      Assert.fail(e.getMessage());
		    }
	 }
		    
	public static void getLinkandReset(String pass1 , String pass2)
	{
		driver.get(emailUtils.testLink());
		
		if(pass1.equals(pass2))
		{
		type("Password1", pass1);
		type("Password2",pass2);
		}
		
		click("NewPassword");
	}

	}
