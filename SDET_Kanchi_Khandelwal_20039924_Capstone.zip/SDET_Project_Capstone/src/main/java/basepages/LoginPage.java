package basepages;

public class LoginPage extends Pages {

	
		 public void clickLogin()
		 {
			 click("Login");
		 }
	
		 public void Username_Password(String username , String password)
		 {
			 type("Username",username);
			 type("LoginPassword",password);
		 }
		 
		 public void SignIn()
		 {
			 click("SignIn");
			System.out.println(driver.getTitle());
		 }
		 
		 public void clickForgetPassword()
		 {
			 click("ForgetPassword");
		 }
		 
		 public void enterusername(String username)
		 {
			 type("Username",username);
		 }
		 
		 public void ResetButton()
		 {
			 click("ResetButton");
		 }
}
