package Utility;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataHelper {
		   public static HashMap<String,String> storeValues = new HashMap<String,String>();
		   
		   public static List<HashMap<String,String>> data(String filepath,String sheetName , int rownum)
		   {
		      List<HashMap<String,String>> mydata = new ArrayList<HashMap<String,String>>();
		      try
		      {
		         FileInputStream fs = new FileInputStream(filepath);
		         XSSFWorkbook workbook = new XSSFWorkbook(fs);
		         XSSFSheet sheet = workbook.getSheet(sheetName);
		         Row HeaderRow = sheet.getRow(0);
		         //for(int i=1;i<sheet.getPhysicalNumberOfRows();i++)
		         //{
		        	 //System.out.println("in loop 1");
		        	 //System.out.println(sheet.getPhysicalNumberOfRows());
		            Row currentRow = sheet.getRow(rownum);
		            HashMap<String,String> currentHash = new HashMap<String,String>();
		            for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
		            {
		            	//System.out.println("In loop 2");
		               Cell currentCell = currentRow.getCell(j);
		            //   System.out.println("in assign");
		               if (currentCell.getCellType() == CellType.STRING) 
		               {
		            	//   System.out.println("assign");
		            	  System.out.print(currentCell.getStringCellValue() + "\t");
		                  currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
		               }
		            
		            }
		            //System.out.println(currentHash);
		            mydata.add(currentHash);
		         //   System.out.println("rows " +i);
		         //}
		         
		         fs.close();
		      }
		      catch (Exception e)
		      {
		         e.printStackTrace();
		      }
		      return mydata;
		   } 
		}
