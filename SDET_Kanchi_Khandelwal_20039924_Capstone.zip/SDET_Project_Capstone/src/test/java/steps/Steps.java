package steps;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.testng.Assert;
import basepages.LoginPage;
import basepages.Pages;
import basepages.RegisterPage;
import basepages.ResetPage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps {

	public static List<HashMap<String, String>> values;
	public static Set<String> sets;
	public static int i = 0;
	RegisterPage page = new RegisterPage();

	LoginPage Loginpage = new LoginPage();
		
	
	@Before
	public void startBrowser()
	{
		Pages.start();
	}
	
	@After
	public void closeBrowser()
	{
		Pages.close();
	}
	
	@Given("Get Data from {string} and {int} and user navigates to {string}")
	public void User_navigates_to(String sheetname,int rownum,String URL) {
		// System.out.println("values:" + values.get(0).get(URL));
		values = Utility.DataHelper.data(
				"C:\\Users\\khand\\Desktop\\SDET-Kanchi_Khandelwal_20039924\\SDET_Project_Capstone\\src\\test\\resources\\SDET_Capstone.xlsx",
				sheetname,rownum);
		
		sets = values.get(0).keySet();
		Pages.navigatetoURL(values.get(0).get(URL));

		if (values.get(0).get(URL).equalsIgnoreCase("https://dreft.com/en-us"))
			i = 1;
		if (values.get(0).get(URL).equalsIgnoreCase("https://www.dreft.com/es-us"))
			i = 2;

	}

	@When("the user navigates to registration page")
	public void user_navigates_to_registration_page_and_get_dataFrom() {
		page.clickRegister();
		
	}

	@And("the user enter details as {string} {string} {string} {string} {string} {string} {string}")
	public void the_user_details_as(String Fname, String Lname, String email, String pass1, String pass2, String bdate,
			String zipcode) throws Exception {
		page.enterName(values.get(0).get(Fname), values.get(0).get(Lname));
		page.EmailPassword(values.get(0).get(email), values.get(0).get(pass2), values.get(0).get(pass2));
		page.BirthDate(values.get(0).get(bdate));
		System.out.println(values.get(0).get(zipcode));
		page.zipcode(values.get(0).get(zipcode));
	}

	@And("^the user accepts terms and condition$")
	public void the_user_accepts_terms_and_condition() {
		page.clickTerms();
	}

	public String text = null;
	@And("^the user creates profile successfully$")
	public void the_user_creates_profile_successfully() {
		
		
		if (i == 1)
			text = "Create Profile Thank You Message";
		if (i == 2)
			text = "Crear p�gina de agradecimiento del perfil";
		
		page.submit();
	Assert.assertTrue(page.titleCheck(text));
	}
	
	@When ("the user navigates to Login page")
	public void the_user_navigates_to_Login_Page_and_get_dataFrom()
	{
		Loginpage.clickLogin();
		
	}
	
	
	@When("the user enter details as {string} and {string}")
	public void the_user_enter_details_as(String username , String Password)
	{
		Loginpage.Username_Password(values.get(0).get(username), values.get(0).get(Password));
	}
	
	@Then("the user login to profile successfully")
	public void the_user_login_to_profile_successfully()
	{
		Loginpage.SignIn();
		
		if(i==2)
		{text = "Ver perfil";
		Assert.assertTrue(page.titleCheck(text));
		}
		
		
	}

	@And("User should click on forget password and user enter {string}")
	public void User_should_click_on_forget_password_and_user_enter (String UserName)
	{
		Loginpage.clickForgetPassword();
		Loginpage.enterusername(values.get(0).get(UserName));
	}
	
	@Then("the user reset button to reset password successfully and {string}")
	public void Reset_Password(String password)
	{
		Loginpage.ResetButton();
		if(i==1)
			text = "Reset my password";
		if(i==2)
			text = "Restablece tu contrase�a";
		
		if(i==2)
		Assert.assertTrue(page.titleCheck(text));
		
		if(i==1)
		{
		ResetPage.connectToEmail();
		password = values.get(0).get(password);
		ResetPage.getLinkandReset(password,password );
		}
	}
	
}
